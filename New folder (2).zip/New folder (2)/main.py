"""
Bobby — FastAPI server

Endpoints:
  POST /chat              — standard request/response
  POST /chat/stream       — server-sent events (streaming)
  POST /generate-image    — DALL-E 3 image generation
  DELETE /history/{user}  — clear a user's history
  GET  /health            — health check (for Railway/Render)
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Depends
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional

from .db    import init_db, close_db, get_message_count, clear_user_history
from .bobby import get_bobby, Bobby


# ── Lifespan ────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield
    await close_db()


# ── App ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="Bobby AI", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # lock this down to your frontend domain in prod
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Schemas ──────────────────────────────────────────────────────────────────
class ChatRequest(BaseModel):
    user_id:      str = Field(..., description="Unique user identifier")
    message:      str = Field(..., description="The user's message")
    image_source: Optional[str] = Field(None, description="URL or path to an image")

class ChatResponse(BaseModel):
    reply:         str
    user_id:       str
    message_count: int

class ImageRequest(BaseModel):
    user_id: str
    prompt:  str
    size:    str = "1024x1024"

class ImageResponse(BaseModel):
    url:            str
    revised_prompt: str
    user_id:        str


# ── Routes ───────────────────────────────────────────────────────────────────
def bobby_dep() -> Bobby:
    return get_bobby()


@app.get("/health")
async def health():
    return {"status": "ok", "service": "bobby"}


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest, bobby: Bobby = Depends(bobby_dep)):
    try:
        reply = await bobby.chat(req.user_id, req.message, req.image_source)
        count = await get_message_count(req.user_id)
        return ChatResponse(reply=reply, user_id=req.user_id, message_count=count)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/chat/stream")
async def chat_stream(req: ChatRequest, bobby: Bobby = Depends(bobby_dep)):
    """
    Server-Sent Events streaming endpoint.
    Client reads: data: <chunk>\n\n
    """
    async def event_stream():
        try:
            async for chunk in bobby.chat_stream(req.user_id, req.message, req.image_source):
                # Escape newlines so SSE framing stays intact
                safe = chunk.replace("\n", "\\n")
                yield f"data: {safe}\n\n"
            yield "data: [DONE]\n\n"
        except Exception as e:
            yield f"data: [ERROR] {str(e)}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@app.post("/generate-image", response_model=ImageResponse)
async def generate_image(req: ImageRequest, bobby: Bobby = Depends(bobby_dep)):
    try:
        url, revised = await bobby.generate_image(req.user_id, req.prompt, req.size)
        return ImageResponse(url=url, revised_prompt=revised, user_id=req.user_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/history/{user_id}")
async def clear_history(user_id: str):
    await clear_user_history(user_id)
    return {"status": "cleared", "user_id": user_id}


@app.get("/history/{user_id}/count")
async def message_count(user_id: str):
    count = await get_message_count(user_id)
    return {"user_id": user_id, "message_count": count}
