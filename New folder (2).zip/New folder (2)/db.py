"""
Database layer — PostgreSQL via asyncpg + Redis for session caching.

Schema:
  users(id, created_at)
  messages(id, user_id, role, content, created_at)

Redis holds the last N turns per user as a hot cache so we don't
hit Postgres on every single chat turn.
"""

import os
import json
import asyncio
from datetime import datetime
from typing import Optional

import asyncpg
import redis.asyncio as aioredis

# ── Config ─────────────────────────────────────────────────────────────────
DATABASE_URL = os.environ["DATABASE_URL"]          # postgres://...
REDIS_URL    = os.environ.get("REDIS_URL", "redis://localhost:6379")

REDIS_TTL_SECONDS  = 60 * 60 * 2   # 2 hours — evict cold sessions from cache
CACHE_WINDOW_TURNS = 40             # turns kept hot in Redis
DB_MAX_HISTORY     = 200            # hard cap fetched from Postgres for summarisation

# ── Connection pools (initialised once at startup) ──────────────────────────
_pg_pool:    Optional[asyncpg.Pool]           = None
_redis_pool: Optional[aioredis.Redis]         = None


async def init_db():
    """Call once at app startup."""
    global _pg_pool, _redis_pool
    _pg_pool = await asyncpg.create_pool(DATABASE_URL, min_size=2, max_size=20)
    _redis_pool = await aioredis.from_url(REDIS_URL, decode_responses=True)
    await _run_migrations()


async def close_db():
    """Call at app shutdown."""
    if _pg_pool:
        await _pg_pool.close()
    if _redis_pool:
        await _redis_pool.aclose()


async def _run_migrations():
    async with _pg_pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id         TEXT PRIMARY KEY,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            CREATE TABLE IF NOT EXISTS messages (
                id         BIGSERIAL PRIMARY KEY,
                user_id    TEXT        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                role       TEXT        NOT NULL CHECK (role IN ('user', 'assistant')),
                content    JSONB       NOT NULL,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            CREATE INDEX IF NOT EXISTS idx_messages_user_created
                ON messages(user_id, created_at DESC);
        """)


# ── Public API ───────────────────────────────────────────────────────────────

async def ensure_user(user_id: str):
    """Create user row if it doesn't exist."""
    async with _pg_pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO users(id) VALUES($1) ON CONFLICT DO NOTHING",
            user_id
        )


async def save_message(user_id: str, role: str, content):
    """Persist a message to Postgres and append to Redis cache."""
    payload = content if isinstance(content, str) else json.dumps(content)

    # 1. Write to Postgres
    async with _pg_pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO messages(user_id, role, content) VALUES($1, $2, $3::jsonb)",
            user_id, role, json.dumps({"role": role, "content": content})
        )

    # 2. Append to Redis list and trim to cache window
    key = f"history:{user_id}"
    entry = json.dumps({"role": role, "content": content})
    async with _redis_pool.pipeline() as pipe:
        pipe.rpush(key, entry)
        pipe.ltrim(key, -CACHE_WINDOW_TURNS * 2, -1)
        pipe.expire(key, REDIS_TTL_SECONDS)
        await pipe.execute()


async def get_recent_history(user_id: str) -> list[dict]:
    """
    Return recent message history for this user.
    Hot path: Redis cache.
    Cold path (cache miss): Postgres with automatic cache warm-up.
    """
    key = f"history:{user_id}"

    # Try Redis first
    cached = await _redis_pool.lrange(key, 0, -1)
    if cached:
        return [json.loads(m) for m in cached]

    # Cache miss — load from Postgres and warm cache
    async with _pg_pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT content FROM messages
            WHERE user_id = $1
            ORDER BY created_at DESC
            LIMIT $2
            """,
            user_id, CACHE_WINDOW_TURNS * 2
        )

    if not rows:
        return []

    messages = [json.loads(r["content"]) for r in reversed(rows)]

    # Warm the cache
    async with _redis_pool.pipeline() as pipe:
        for m in messages:
            pipe.rpush(key, json.dumps(m))
        pipe.expire(key, REDIS_TTL_SECONDS)
        await pipe.execute()

    return messages


async def get_message_count(user_id: str) -> int:
    async with _pg_pool.acquire() as conn:
        return await conn.fetchval(
            "SELECT COUNT(*) FROM messages WHERE user_id = $1", user_id
        )


async def clear_user_history(user_id: str):
    async with _pg_pool.acquire() as conn:
        await conn.execute("DELETE FROM messages WHERE user_id = $1", user_id)
    await _redis_pool.delete(f"history:{user_id}")
