"""
Bobby core — async, production-ready.
Handles chat, vision, and image generation with full persistent memory.
"""

import os
import re
import base64
from typing import Optional, AsyncIterator

import anthropic
import openai
import httpx
from pathlib import Path

from .db      import ensure_user, save_message, get_recent_history
from .history import build_context

# ── Config ─────────────────────────────────────────────────────────────────
CHAT_MODEL      = "claude-sonnet-4-6"
SUMMARY_MODEL   = "claude-haiku-4-5-20251001"
IMAGE_GEN_MODEL = "dall-e-3"
MAX_TOKENS      = 4096

BOBBY_SYSTEM_PROMPT = """You are Bobby — a brilliant, warm, and witty AI assistant.

Your personality:
- Friendly and conversational; you feel like a smart friend, not a corporate bot.
- Genuinely funny when appropriate, never forced. Light sarcasm is fine.
- Concise by default, but thorough when depth is needed.
- You celebrate user wins and encourage learning.

Your skills:
- Expert-level coding in Python, JavaScript, TypeScript, Rust, SQL, bash, and more.
  When writing code: add brief inline comments, explain your reasoning, and offer to
  debug or extend on request.
- Image analysis: describe what you see clearly and specifically.
- You know when to be serious (debugging a production bug) vs. playful (casual chat).

Always be honest when you're uncertain. Never make up facts."""


# ── Image helpers ───────────────────────────────────────────────────────────
async def _load_image(source: str) -> tuple[str, str]:
    ext = Path(source).suffix.lower().lstrip(".")
    mime_map = {"jpg": "image/jpeg", "jpeg": "image/jpeg",
                "png": "image/png", "gif": "image/gif", "webp": "image/webp"}
    media_type = mime_map.get(ext, "image/jpeg")

    if source.startswith(("http://", "https://")):
        async with httpx.AsyncClient() as client:
            r = await client.get(source, follow_redirects=True, timeout=15)
            r.raise_for_status()
            data = base64.standard_b64encode(r.content).decode()
            ct = r.headers.get("content-type", "")
            if "png" in ct: media_type = "image/png"
            elif "webp" in ct: media_type = "image/webp"
    else:
        with open(source, "rb") as f:
            data = base64.standard_b64encode(f.read()).decode()

    return data, media_type


# ── Bobby ───────────────────────────────────────────────────────────────────
class Bobby:
    def __init__(self):
        self._anthropic = anthropic.AsyncAnthropic(
            api_key=os.environ["ANTHROPIC_API_KEY"]
        )
        self._openai = openai.AsyncOpenAI(
            api_key=os.environ["OPENAI_API_KEY"]
        )

    async def chat(
        self,
        user_id: str,
        message: str,
        image_source: Optional[str] = None,
    ) -> str:
        """Send a message and get Bobby's response. Fully persistent."""
        await ensure_user(user_id)

        # Build content (text or multimodal)
        if image_source:
            img_data, media_type = await _load_image(image_source)
            content = [
                {"type": "image", "source": {
                    "type": "base64", "media_type": media_type, "data": img_data
                }},
                {"type": "text", "text": message or "What's in this image?"},
            ]
        else:
            content = message

        # Persist user turn
        await save_message(user_id, "user", content)

        # Load history and apply smart context management
        history = await get_recent_history(user_id)
        system, trimmed_history = await build_context(history, BOBBY_SYSTEM_PROMPT)

        # Call Claude
        response = await self._anthropic.messages.create(
            model=CHAT_MODEL,
            max_tokens=MAX_TOKENS,
            system=system,
            messages=trimmed_history,
        )

        reply = response.content[0].text

        # Persist assistant turn
        await save_message(user_id, "assistant", reply)

        return reply

    async def chat_stream(
        self,
        user_id: str,
        message: str,
        image_source: Optional[str] = None,
    ) -> AsyncIterator[str]:
        """Streaming version — yields text chunks as they arrive."""
        await ensure_user(user_id)

        content = message
        if image_source:
            img_data, media_type = await _load_image(image_source)
            content = [
                {"type": "image", "source": {
                    "type": "base64", "media_type": media_type, "data": img_data
                }},
                {"type": "text", "text": message or "What's in this image?"},
            ]

        await save_message(user_id, "user", content)

        history = await get_recent_history(user_id)
        system, trimmed_history = await build_context(history, BOBBY_SYSTEM_PROMPT)

        full_reply = []
        async with self._anthropic.messages.stream(
            model=CHAT_MODEL,
            max_tokens=MAX_TOKENS,
            system=system,
            messages=trimmed_history,
        ) as stream:
            async for text in stream.text_stream:
                full_reply.append(text)
                yield text

        await save_message(user_id, "assistant", "".join(full_reply))

    async def generate_image(
        self,
        user_id: str,
        prompt: str,
        size: str = "1024x1024",
    ) -> tuple[str, str]:
        """Generate an image. Returns (url, revised_prompt)."""
        await ensure_user(user_id)

        response = await self._openai.images.generate(
            model=IMAGE_GEN_MODEL,
            prompt=prompt,
            size=size,
            quality="hd",
            n=1,
        )

        url     = response.data[0].url
        revised = response.data[0].revised_prompt

        await save_message(user_id, "user", f"[Image generation] {prompt}")
        await save_message(user_id, "assistant",
            f"Generated image for: {prompt}\nRevised prompt: {revised}\nURL: {url}")

        return url, revised


# ── Singleton ───────────────────────────────────────────────────────────────
_bobby: Optional[Bobby] = None

def get_bobby() -> Bobby:
    global _bobby
    if _bobby is None:
        _bobby = Bobby()
    return _bobby
