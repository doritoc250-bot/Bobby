"""
Smart history management for users with large message counts.

Strategy:
  - Keep the last RECENT_TURNS turns verbatim (Claude needs exact recent context).
  - If the user has more than SUMMARISE_THRESHOLD total messages, summarise
    older turns into a compact "memory block" and prepend it as a system note.
  - This keeps every request well within Claude's context window regardless of
    how many lifetime messages a user has.
"""

import os
import json
from typing import Optional

import anthropic

RECENT_TURNS        = 20    # turns always sent verbatim
SUMMARISE_THRESHOLD = 30    # total turns before we start summarising older ones
SUMMARY_MODEL       = "claude-haiku-4-5-20251001"   # fast + cheap for summarisation

_client = anthropic.AsyncAnthropic(api_key=os.environ["ANTHROPIC_API_KEY"])


async def build_context(
    all_history: list[dict],
    system_prompt: str,
) -> tuple[str, list[dict]]:
    """
    Given the full history for a user, return:
      (effective_system_prompt, trimmed_messages)

    If history is short, returns as-is.
    If history is long, older messages are summarised and injected into the system prompt.
    """
    if len(all_history) <= SUMMARISE_THRESHOLD * 2:
        return system_prompt, all_history

    # Split: old turns to summarise vs recent turns to keep verbatim
    cutoff         = len(all_history) - (RECENT_TURNS * 2)
    old_messages   = all_history[:cutoff]
    recent_messages = all_history[cutoff:]

    summary = await _summarise(old_messages)

    enriched_system = (
        f"{system_prompt}\n\n"
        f"--- MEMORY (summary of earlier conversation) ---\n{summary}\n"
        f"--- END MEMORY ---\n"
        f"The above is a compressed summary of the user's earlier messages. "
        f"The most recent messages follow in full."
    )

    return enriched_system, recent_messages


async def _summarise(messages: list[dict]) -> str:
    """Use a fast model to compress old turns into a memory block."""
    # Format messages for summarisation prompt
    formatted = []
    for m in messages:
        role = m.get("role", "unknown")
        content = m.get("content", "")
        if isinstance(content, list):
            # Multimodal: extract text parts only for summary
            text_parts = [p["text"] for p in content if p.get("type") == "text"]
            content = " ".join(text_parts)
        formatted.append(f"{role.upper()}: {content}")

    conversation_text = "\n".join(formatted)

    response = await _client.messages.create(
        model=SUMMARY_MODEL,
        max_tokens=600,
        messages=[{
            "role": "user",
            "content": (
                "Summarise the following conversation history into a compact memory block. "
                "Capture: key facts the user shared about themselves, important decisions made, "
                "topics explored, code written, problems solved, and any preferences expressed. "
                "Be concise. Use bullet points. This will be given to an AI assistant as context.\n\n"
                f"{conversation_text}"
            )
        }]
    )

    return response.content[0].text
